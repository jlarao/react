# Backend MERN - Calendar

## Development

1. Instalar dependencias `npm install`
2. Clonar el archivo `.env.template` y renombrarlo a `.env`
3. Cambiar las variables de entorno acorde a tu configuración
4. Correr el servidor `npm start`
