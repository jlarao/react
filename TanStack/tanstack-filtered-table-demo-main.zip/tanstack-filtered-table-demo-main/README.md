# TanStack Table + Router + Query

A demo implementing backend pagination, filtering and sorting on TanStack Table, with TanStack Query holding the async state and TanStack Router managing the local state in the URL query parameters.

Watch me doing a walkthrough of the code on [YouTube](https://www.youtube.com/watch?v=F4zshDInsJY).
